module.exports = {
  plugins: {
    'postcss-preset-env': {},
    // 'postcss-import': {},
    // 'autoprefixer': {},
    'postcss-object-fit-images': {},
  },
};
