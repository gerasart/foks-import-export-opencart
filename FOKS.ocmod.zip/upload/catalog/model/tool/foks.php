<?php
    
    class ModelToolFoks extends Model {
    
    }
